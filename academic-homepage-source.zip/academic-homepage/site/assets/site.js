(() => {
  'use strict';
  const root = document.documentElement;
  const toggle = document.getElementById('language-toggle');
  const status = document.getElementById('copy-status');
  function setLanguage(language) {
    const zh = language === 'zh';
    root.dataset.language = zh ? 'zh' : 'en';
    root.lang = zh ? 'zh-CN' : 'en';
    toggle.textContent = zh ? 'English' : '中文';
    toggle.setAttribute('aria-label', zh ? 'Switch to English' : '切换为中文');
    try { localStorage.setItem('chan-xu-language', language); } catch (_) { /* Storage is optional. */ }
  }
  toggle.hidden = false;
  try { setLanguage(localStorage.getItem('chan-xu-language') || 'en'); } catch (_) { setLanguage('en'); }
  toggle.addEventListener('click', () => setLanguage(root.dataset.language === 'zh' ? 'en' : 'zh'));
  document.querySelectorAll('.copy-button').forEach(button => {
    button.hidden = false;
    button.addEventListener('click', async () => {
      const code = button.parentElement.querySelector('code');
      const zh = root.dataset.language === 'zh';
      try {
        if (!navigator.clipboard || !window.isSecureContext) throw new Error('Clipboard unavailable');
        await navigator.clipboard.writeText(code.textContent);
        status.textContent = zh ? '引用已复制。' : 'Citation copied.';
        button.textContent = zh ? '已复制' : 'Copied';
      } catch (_) {
        const range = document.createRange();
        range.selectNodeContents(code);
        const selection = window.getSelection();
        selection.removeAllRanges(); selection.addRange(range);
        status.textContent = zh ? '引用已选中，请使用复制快捷键。' : 'Citation selected. Use your copy shortcut.';
        button.textContent = zh ? '已选中，请手动复制' : 'Selected — copy manually';
      }
      window.setTimeout(() => { button.innerHTML = '<span lang="en" class="en">Copy citation</span><span lang="zh-CN" class="zh">复制引用</span>'; }, 2500);
    });
  });
})();
