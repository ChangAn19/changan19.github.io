(() => {
  'use strict';
  const root = document.documentElement;
  const toggle = document.getElementById('language-toggle');
  const copyStatus = document.getElementById('copy-status');
  const filterStatus = document.getElementById('filter-status');
  const emptyState = document.getElementById('empty-state');
  const publications = document.getElementById('publications');
  const papers = Array.from(document.querySelectorAll('article.paper'));
  const groups = Array.from(document.querySelectorAll('.work-group'));
  const viewButtons = Array.from(document.querySelectorAll('button[data-view]'));
  const topicButtons = Array.from(document.querySelectorAll('button[data-topic]'));
  const filters = { view: 'all', topic: 'all' };
  const copyTimers = new WeakMap();
  const isChinese = () => root.dataset.language === 'zh';

  function updateFilters() {
    let visibleCount = 0;
    papers.forEach(paper => {
      const matchesView = filters.view === 'all' || paper.dataset.first === 'true';
      const topics = (paper.dataset.topics || '').split(/\s+/);
      const matchesTopic = filters.topic === 'all' || topics.includes(filters.topic);
      paper.hidden = !(matchesView && matchesTopic);
      if (!paper.hidden) visibleCount += 1;
    });
    groups.forEach(group => {
      const count = Array.from(group.querySelectorAll('article.paper')).filter(paper => !paper.hidden).length;
      group.hidden = count === 0;
      const counter = group.querySelector('.group-count[data-count]');
      if (counter) counter.textContent = String(count).padStart(2, '0');
    });
    if (publications) publications.hidden = !Array.from(publications.querySelectorAll('article.paper')).some(paper => !paper.hidden);
    viewButtons.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.view === filters.view)));
    topicButtons.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.topic === filters.topic)));
    if (emptyState) emptyState.hidden = visibleCount !== 0;
    if (filterStatus) filterStatus.textContent = isChinese()
      ? `显示 ${visibleCount} / ${papers.length} 篇论文`
      : `Showing ${visibleCount} of ${papers.length} works`;
  }

  function setLanguage(language) {
    const zh = language === 'zh';
    root.dataset.language = zh ? 'zh' : 'en';
    root.lang = zh ? 'zh-CN' : 'en';
    if (toggle) {
      toggle.textContent = zh ? 'English' : '中文';
      toggle.setAttribute('aria-label', zh ? 'Switch to English' : '切换为中文');
    }
    try { localStorage.setItem('chan-xu-language', root.dataset.language); } catch (_) { /* Storage is optional. */ }
    updateFilters();
  }
  viewButtons.forEach(button => button.addEventListener('click', () => {
    filters.view = button.dataset.view;
    updateFilters();
  }));
  topicButtons.forEach(button => button.addEventListener('click', () => {
    filters.topic = button.dataset.topic;
    updateFilters();
  }));
  if (filterStatus) {
    filterStatus.setAttribute('role', 'status');
    filterStatus.setAttribute('aria-live', 'polite');
    filterStatus.setAttribute('aria-atomic', 'true');
  }
  let savedLanguage = 'en';
  try { savedLanguage = localStorage.getItem('chan-xu-language') || 'en'; } catch (_) { /* Use the default language. */ }
  setLanguage(savedLanguage);
  document.querySelectorAll('.publication-tools').forEach(tools => { tools.hidden = false; });
  if (toggle) {
    toggle.hidden = false;
    toggle.addEventListener('click', () => setLanguage(isChinese() ? 'en' : 'zh'));
  }
  function resetForAnchor() {
    if (!['#accepted', '#publications'].includes(window.location.hash)) return;
    if (filters.view === 'all' && filters.topic === 'all') return;
    filters.view = 'all';
    filters.topic = 'all';
    updateFilters();
    const target = document.getElementById(window.location.hash.slice(1));
    if (target) target.scrollIntoView({ block: 'start' });
  }
  window.addEventListener('hashchange', resetForAnchor);
  document.querySelectorAll('a[href="#accepted"], a[href="#publications"]').forEach(link => {
    link.addEventListener('click', () => {
      filters.view = 'all';
      filters.topic = 'all';
      updateFilters();
    });
  });
  document.querySelectorAll('.copy-button').forEach(button => {
    button.hidden = false;
    button.addEventListener('click', async () => {
      const code = button.parentElement.querySelector('code');
      if (!code) return;
      window.clearTimeout(copyTimers.get(button));
      try {
        if (!navigator.clipboard || !window.isSecureContext) throw new Error('Clipboard unavailable');
        await navigator.clipboard.writeText(code.textContent);
        if (copyStatus) copyStatus.textContent = isChinese() ? '引用已复制。' : 'Citation copied.';
        button.textContent = isChinese() ? '已复制' : 'Copied';
      } catch (_) {
        const range = document.createRange();
        range.selectNodeContents(code);
        const selection = window.getSelection();
        if (selection) {
          selection.removeAllRanges();
          selection.addRange(range);
        }
        if (copyStatus) copyStatus.textContent = isChinese() ? '引用已选中，请使用复制快捷键。' : 'Citation selected. Use your copy shortcut.';
        button.textContent = isChinese() ? '已选中，请手动复制' : 'Selected — copy manually';
      }
      copyTimers.set(button, window.setTimeout(() => {
        button.innerHTML = '<span lang="en" class="en">Copy citation</span><span lang="zh-CN" class="zh">复制引用</span>';
      }, 2500));
    });
  });
})();
