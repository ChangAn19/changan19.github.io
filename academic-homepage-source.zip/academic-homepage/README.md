# 许阐 / Chan Xu 的个人学术主页

为 GitHub 用户 **ChangAn19** 制作，已部署到 `https://changan19.github.io/`。

网站主内容只包含 Research Works，采用个人信息侧栏和横向论文列表。包含中英文切换、独立的 Accepted / 已接收论文分组、6 篇原有论文、年份分组、主题与第一作者筛选、DOI 和 Google Scholar 链接、红色 PDF 下载按钮、BibTeX 查看/复制/下载及手机端布局。没有追踪脚本、外部字体或需要付费的服务。

## 本机查看

双击 `site/index.html` 即可查看；浏览器不允许读取剪贴板时，“复制引用”会选中文字，按 Ctrl+C 即可。

可选：在本目录运行 `python -m http.server 8765 --bind 127.0.0.1 --directory site`，访问 `http://127.0.0.1:8765/`。

## 发布到 GitHub Pages

本次通过浏览器发布时，`python package_site.py` 将生成 `upload/`：里面的 `index.html` 已内嵌样式与脚本，同时包含 BibTeX、来源说明、完整源码 ZIP。将 `upload/` 内文件上传到仓库根目录，Pages 选择 **Deploy from a branch → main → /(root)** 即可。更新时运行 `python build.py`、`python package_site.py` 后重新上传这些文件。

也可改用已经准备好的 GitHub Actions 自动生成与发布：

1. 登录 ChangAn19，新建 **Public** 仓库，名称填 `changan19.github.io`。如果已存在同名仓库，先保留原站内容，不要直接覆盖。
2. 将本项目文件上传到仓库根目录，保留目录结构。根目录应有 `content.json`、`build.py`、`site/` 和 `.github/workflows/pages.yml`。不要上传上层的研究资料文件夹。
3. 仓库进入 **Settings → Pages → Build and deployment → Source → GitHub Actions**。
4. 打开 **Actions → Publish academic homepage → Run workflow**，选择 `main`。以后每次向 `main` 提交都会自动重新生成并部署。
5. 等工作流成功后，打开 `https://changan19.github.io/`。首次生效可能需要几分钟。

只想手动上传静态页面，也可以把 `site/` **里面的内容**上传到仓库根目录（让 `index.html` 直接位于根目录），然后在 Pages 中选 **Deploy from a branch → main → /(root)**。此方式不需要 Python，但日后修改 `content.json` 不会自动更新网页；须在本机执行 `python build.py` 后重新上传 `site/` 内容。

官方说明：

- [创建 GitHub Pages 网站](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site)
- [使用自定义 Actions 工作流发布](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages)

## 日后添加或修改论文

只需修改 `content.json` 的 `publications` 数组，复制已有条目即可。每篇 `id` 必须唯一；年份决定分组，同年按数组中的次序排列。`authors` 为作者缩写，`authors_full` 为经过核实的完整作者姓名。更新 `updated` 日期。

`topics` 为主题筛选标签，可使用 `skills`、`stiffness`、`features`，一篇可有多个。真实论文图放在 `site/assets/`，在条目中设置 `thumbnail` 和描述内容的 `thumbnail_alt`。当前 7 篇论文均使用对应原论文的方法框架图或实验示意图，来源页码和图号见 `SOURCES.md`。生成器读取每张 PNG 的实际尺寸，保留原始纵横比。打包器将缩略图内嵌到发布 HTML，无需单独上传图片。

已接收但尚未发表的条目设置 `"status": "accepted"`、`"accepted_date": "2026-09-25"`，会自动出现在独立 Accepted 栏目，并按接收日期排序。未有 Scholar 条目可设 `"scholar_id": null`，网页不会生成无效 Scholar 链接。BibTeX 自动增加 Accepted for publication 注释。正式发表后将 `status` 改成 `published`，再补充实际出版年份、卷期、页码与 Scholar 信息。

本机运行 `python build.py` 会生成网页和 BibTeX，不需要安装额外 Python 包。启用 Actions 后，直接在 GitHub 编辑并提交 `content.json` 也会自动完成生成和发布。

职称、学历、个人邮箱和照片没有编造；目前仅放置已确认的单位、姓名和研究方向。引用次数没有固定写入网页，访客可通过 Google Scholar 查看实时数据。Google Scholar 论文列表不会自动抓取更新。

## 添加作者接收稿 PDF

当前新增的 SC-DMPs 已接收论文提供作者稿 PDF，副本前附版权说明页，原 12 页正文保持不变。未提供 PDF 的论文条目仍使用 `"pdf": null`，不会出现空白下载按钮。

IEEE 官方允许符合规定的作者接收稿放在作者个人网站。其 Personal Server 定义包括由作者/雇主拥有并控制的网站或仓库；作者自己控制的 GitHub Pages 主页与此定义相符是解释性判断，官方并未点名 GitHub Pages。

每篇论文先核对签署的出版协议与所持文件版本。标准非开放获取论文不要上传出版商排版 PDF 或校样；开放获取论文按对应许可处理。

确认后：

1. 将可公开的作者接收稿放入 `site/papers/`，建议使用英文文件名。
2. 按该论文版权年份，在 PDF 首页加入适用的 IEEE 版权声明、完整引文和 DOI。完整声明从官方政策页的 **Accepted article** 部分核对后复制。
3. 在该论文数据中设置 `pdf`（例如 `papers/xu-2025-robust-accepted.pdf`）、`copyright_year` 和 `copyright_notice`（经核对的完整版权声明），保留正确 `doi`。
4. 执行 `python build.py`，核对生成的“作者接收稿 · PDF”链接和声明，再发布。

使用当前浏览器上传方式时，继续执行 `python package_site.py`。它只复制数据中明确指定的 PDF，将文件放入 `upload/` 根目录，并同步改写网页链接。上传时，必须把 PDF 与生成的 `index.html`、`publications.bib` 一起上传到仓库根目录；不同 PDF 的文件名不能重复。

生成器检查 PDF 是否存在、是否位于 `site/papers/`，以及是否提供版权年、声明和 DOI；它不能代替对稿件版本及出版协议的审查。仓库本身为公开仓库，提交进去的文件即已公开，不能只依赖网页是否提供链接来判断公开性。

[IEEE 官方发表后分享政策](https://journals.ieeeauthorcenter.ieee.org/become-an-ieee-journal-author/publishing-ethics/guidelines-and-policies/post-publication-policies/)

## 文件说明

| 文件 | 用途 |
| --- | --- |
| `content.json` | 姓名、链接、论文数据 |
| `build.py` | 生成静态 HTML 与 BibTeX |
| `site/index.html` | 可直接打开的主页 |
| `site/assets/style.css` | 样式与响应式布局 |
| `site/assets/site.js` | 语言切换、论文筛选、引用复制 |
| `site/publications.bib` | 全部论文的 BibTeX |
| `site/papers/` | 日后添加经确认的作者接收稿 |
| `.github/workflows/pages.yml` | 自动构建与发布 |
| `SOURCES.md` | 资料核验来源与取舍 |

资料截至 2026-09-29。
