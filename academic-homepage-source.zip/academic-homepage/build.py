"""Build the static homepage using Python's standard library: python build.py."""
import html
import json
import struct
from datetime import date
from pathlib import Path
from urllib.parse import quote

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "site"
DATA = json.loads((ROOT / "content.json").read_text(encoding="utf-8"))
E = html.escape
POLICY = "https://journals.ieeeauthorcenter.ieee.org/become-an-ieee-journal-author/publishing-ethics/guidelines-and-policies/post-publication-policies/"


def bi(en, zh):
    return f'<span lang="en" class="en">{E(en)}</span><span lang="zh-CN" class="zh">{E(zh)}</span>'


def bibtex(p):
    kind = "article" if p["type"] == "journal" else "inproceedings"
    venue = "journal" if p["type"] == "journal" else "booktitle"
    authors = " and ".join(f'{a.split()[-1]}, {" ".join(a.split()[:-1])}' for a in p.get("authors_full", p["authors"]))
    fields = {"title": "{" + p["title"] + "}", "author": authors, venue: p["venue"], "year": str(p["year"])}
    for key in ("volume", "number", "pages", "doi"):
        if p.get(key):
            fields[key] = str(p[key]).replace("--", "-").replace("-", "--") if key == "pages" else str(p[key])
    if p.get("status") == "accepted":
        fields["note"] = "Accepted for publication on " + p["accepted_date"]
    return "@" + kind + "{" + p["id"] + ",\n" + ",\n".join(f"  {k} = {{{v}}}" for k, v in fields.items()) + "\n}"


def paper(p, index):
    names = p.get("authors_full", p["authors"])
    authors = ", ".join(f'<strong>{E(a)}</strong>' if a in ("C. Xu", DATA["name"]) else E(a) for a in names)
    scholar = ("https://scholar.google.com/citations?view_op=view_citation&user=MgbQBswAAAAJ&citation_for_view=MgbQBswAAAAJ:" + quote(p["scholar_id"])) if p.get("scholar_id") else None
    url = "https://doi.org/" + p["doi"] if p.get("doi") else scholar
    first = f'<span class="first-author">{bi("First author", "第一作者")}</span>' if names[0] in ("C. Xu", DATA["name"]) else ""
    pdf = ""
    copyright = ""
    if p.get("pdf"):
        path = (OUT / p["pdf"]).resolve()
        if not path.is_relative_to((OUT / "papers").resolve()) or not path.is_file():
            raise ValueError(f"PDF must exist inside site/papers: {p['id']}")
        if not p.get("copyright_year") or not p.get("copyright_notice") or not p.get("doi"):
            raise ValueError("Add the verified copyright year, required notice, and DOI before publishing a manuscript")
        pdf_icon = '<svg class="pdf-icon" viewBox="0 0 32 38" aria-hidden="true" focusable="false"><path d="M5 1h15l10 10v24a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2Z" fill="currentColor"/><path d="M20 1v10h10" fill="#fff" opacity=".35"/><text x="16" y="27" text-anchor="middle" fill="#fff" font-family="Arial,sans-serif" font-size="11" font-weight="700">PDF</text></svg>'
        pdf = f'<a class="pdf-link" href="{E(p["pdf"], quote=True)}" download>{pdf_icon}<span class="pdf-label"><span class="pdf-title">{bi("Download PDF", "下载 PDF")}</span><span class="pdf-description">{bi("Accepted manuscript", "作者接收稿")}</span></span></a>'
        copyright = f'<p class="copyright-notice">{E(p["copyright_notice"])}</p>'
    kind = bi("Journal article", "期刊论文") if p["type"] == "journal" else bi("Conference paper", "会议论文")
    citation = bibtex(p)
    accepted = p.get("status") == "accepted"
    status = f'<span class="accepted-badge">{bi("Accepted", "已接收")}</span>' if accepted else ""
    acceptance = ""
    if accepted:
        accepted_date = date.fromisoformat(p["accepted_date"])
        acceptance = f'<p class="acceptance-date">{bi("Accepted on", "接收日期")} <time datetime="{accepted_date.isoformat()}">{accepted_date:%Y-%m-%d}</time></p>'
    title = f'<a href="{E(url)}" target="_blank" rel="noopener">{E(p["title"])}</a>' if url else E(p["title"])
    links = []
    if p.get("doi"):
        label = "DOI: " + E(p["doi"]) if accepted else bi("Publisher", "出版商页面")
        links.append(f'<a href="https://doi.org/{E(p["doi"], quote=True)}" target="_blank" rel="noopener">{label}</a>')
    if scholar:
        links.append(f'<a href="{E(scholar)}" target="_blank" rel="noopener">Google Scholar</a>')
    if p.get('thumbnail'):
        thumbnail = (OUT / p['thumbnail']).resolve()
        if not thumbnail.is_relative_to((OUT / 'assets').resolve()) or not thumbnail.is_file():
            raise ValueError(f"Thumbnail must exist inside site/assets: {p['id']}")
        image_header = thumbnail.read_bytes()[:24]
        if image_header[:8] != b'\x89PNG\r\n\x1a\n':
            raise ValueError(f"Thumbnail must be a PNG: {p['id']}")
        image_width, image_height = struct.unpack('>II', image_header[16:24])
        visual = f'<img src="{E(p["thumbnail"], quote=True)}" alt="{E(p["thumbnail_alt"], quote=True)}" width="{image_width}" height="{image_height}" loading="lazy">'
    else:
        visual = f'<div class="venue-tile" aria-hidden="true"><small>{p["year"]}</small><strong>{E(p["venue_short"])}</strong><span>{kind}</span></div>'
    topics = ' '.join(p.get('topics', []))
    return f'''<article class="paper" id="{E(p['id'])}" aria-labelledby="title-{E(p['id'])}" data-first="{'true' if first else 'false'}" data-topics="{E(topics, quote=True)}">
      <div class="paper-visual">{visual}</div>
      <div class="paper-content">
        <div class="paper-meta"><span class="venue-short">{E(p['venue_short'])}</span><span>{kind}</span>{first}{status}</div>
        <h4 id="title-{E(p['id'])}">{title}</h4>
        <p class="authors">{authors}</p>
        <p class="venue">{E(p['venue'])}{', ' + E(str(p['volume'])) if p.get('volume') else ''}{'(' + E(str(p['number'])) + ')' if p.get('number') else ''}{', pp. ' + E(p['pages']) if p.get('pages') else ''} · {p['year']}</p>
        {acceptance}
        <div class="paper-actions">{pdf}{''.join(links)}
        <details class="citation"><summary aria-label="BibTeX: {E(p['title'], quote=True)}">BibTeX</summary><div class="citation-box"><pre><code>{E(citation)}</code></pre><button class="copy-button" type="button" hidden>{bi("Copy citation", "复制引用")}</button></div></details>
        </div>
      </div>
      {copyright}
    </article>'''


OUT.mkdir(exist_ok=True)
all_papers = DATA["publications"]
if len({p["id"] for p in all_papers}) != len(all_papers):
    raise ValueError("Publication ids must be unique")
if any(p.get("status", "published") not in {"published", "accepted"} for p in all_papers):
    raise ValueError("Publication status must be published or accepted")
accepted_papers = sorted((p for p in all_papers if p.get("status") == "accepted"), key=lambda p: p["accepted_date"], reverse=True)
pubs = sorted((p for p in all_papers if p.get("status") != "accepted"), key=lambda p: p["year"], reverse=True)
accepted_section = ""
accepted_nav = ""
if accepted_papers:
    accepted_cards = ''.join(paper(p, i) for i, p in enumerate(accepted_papers, 1))
    accepted_section = f'<section id="accepted" class="work-group accepted-publications" aria-labelledby="accepted-heading"><h3 id="accepted-heading" class="group-title">{bi("Accepted", "已接收论文")}<span class="group-count" data-count>{len(accepted_papers)}</span></h3>{accepted_cards}</section>'
    accepted_nav = f'<a href="#accepted">{bi("Accepted", "已接收")}</a>'
sections, count = [], 0
for year in sorted({p["year"] for p in pubs}, reverse=True):
    papers = [p for p in pubs if p["year"] == year]
    cards = []
    for p in papers:
        count += 1
        cards.append(paper(p, count))
    sections.append(f'<section class="year-group work-group" aria-labelledby="year-{year}"><h3 id="year-{year}" class="group-title">{year}<span class="group-count" data-count>{len(papers)}</span></h3>{"".join(cards)}</section>')

structured = {"@context": "https://schema.org", "@type": "Person", "name": DATA["name"], "alternateName": DATA["name_zh"], "url": f'https://{DATA["github"].lower()}.github.io/', "sameAs": [DATA["scholar"], f'https://github.com/{DATA["github"]}'], "affiliation": {"@type": "Organization", "name": "Ningbo Institute of Materials Technology and Engineering, Chinese Academy of Sciences"}, "knowsAbout": ["Skill learning", "Imitation learning", "Pattern recognition", "Human-robot interaction"]}
page = f'''<!doctype html>
<html lang="en" data-language="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="theme-color" content="#090c0c">
  <title>{E(DATA['name'])} · {E(DATA['name_zh'])} | Research Works</title>
  <meta name="description" content="Chan Xu (许阐) — research and publications in skill learning, imitation learning, pattern recognition, and human-robot interaction at NIMTE, Chinese Academy of Sciences.">
  <meta property="og:title" content="Chan Xu | Research Works">
  <meta property="og:description" content="Research and publications · Ningbo Institute of Materials Technology and Engineering, Chinese Academy of Sciences.">
  <meta property="og:type" content="website">
  <link rel="canonical" href="https://changan19.github.io/">
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='12' fill='%23173bb5'/%3E%3Ctext x='32' y='42' text-anchor='middle' font-family='Arial' font-size='30' font-weight='700' fill='white'%3ECX%3C/text%3E%3C/svg%3E">
  <link rel="stylesheet" href="assets/style.css">
  <script src="assets/site.js" defer></script>
  <script type="application/ld+json">{json.dumps(structured, ensure_ascii=False).replace('<', chr(92) + 'u003c')}</script>
</head>
<body>
<a class="skip-link" href="#research-works">{bi('Skip to research works', '跳转到研究成果')}</a>
<main id="top" class="layout">
  <aside class="profile" aria-labelledby="profile-name">
    <div class="profile-mark" aria-hidden="true">CX</div>
    <h1 id="profile-name">Chan Xu<span class="chinese-name">许阐</span></h1>
    <p class="affiliation">{bi('Ningbo Institute of Materials Technology and Engineering', '中国科学院宁波材料技术与工程研究所')}</p>
    <p class="academy">Chinese Academy of Sciences</p>
    <p class="location">{bi('Ningbo, China', '中国 · 宁波')}</p>
    <div class="profile-links"><a href="{E(DATA['scholar'])}" target="_blank" rel="noopener">Google Scholar <span aria-hidden="true">↗</span></a><a href="https://github.com/{E(DATA['github'])}" target="_blank" rel="noopener">GitHub <span aria-hidden="true">↗</span></a></div>
    <nav class="profile-nav" aria-label="Main navigation"><a href="#research-works" aria-current="page">Research Works</a></nav>
    <button id="language-toggle" type="button" aria-label="切换为中文" hidden>中文</button>
  </aside>
  <div class="main-column">
    <section id="research-works" aria-labelledby="works-heading">
    <header class="works-header"><div class="heading-line"><span class="works-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 4h16v16H4zM8 8h8M8 12h8M8 16h5"/></svg></span><h2 id="works-heading">Research Works</h2></div><p class="works-summary">{bi('Publications in skill learning, interaction stiffness estimation, and feature selection.', '技能学习、交互刚度估计与特征选择相关论文。')}</p></header>
    <div class="publication-tools" hidden>
      <div class="view-options" role="group" aria-label="Publication view"><span>{bi('Publications', '论文')}</span><button type="button" data-view="all" aria-pressed="true">{bi('All by date', '全部 · 按年份')}</button><button type="button" data-view="first" aria-pressed="false">{bi('First author', '第一作者')}</button></div>
      <div class="topic-options" role="group" aria-label="Filter by topic"><span>{bi('Topics', '主题')}</span><button type="button" data-topic="all" aria-pressed="true">{bi('All', '全部')}</button><button type="button" data-topic="skills" aria-pressed="false">{bi('Skill learning', '技能学习')}</button><button type="button" data-topic="stiffness" aria-pressed="false">{bi('Stiffness estimation', '刚度估计')}</button><button type="button" data-topic="features" aria-pressed="false">{bi('Feature selection', '特征选择')}</button></div>
    </div>
    <div class="works-toolbar"><p id="filter-status" role="status" aria-live="polite">{bi(f'{len(all_papers)} publications', f'{len(all_papers)} 篇论文')}</p><a class="bib-download" href="publications.bib" download>{bi('Download BibTeX', '下载 BibTeX')}</a></div>
    {accepted_section}
    <section id="publications" class="publications" aria-label="Published papers">
      {''.join(sections)}
    </section>
    <p id="empty-state" hidden>{bi('No publications match these filters.', '没有符合当前筛选条件的论文。')}</p>
    </section>
    <footer><span>© {DATA['updated'][:4]} Chan Xu</span><span>{bi('Updated', '更新日期')} <time datetime="{DATA['updated']}">{DATA['updated']}</time></span><a href="{POLICY}" target="_blank" rel="noopener">{bi('Article sharing policy', '论文分享政策')}</a></footer>
  </div>
</main>
<div id="copy-status" class="sr-only" role="status" aria-live="polite"></div>
</body></html>'''
(OUT / "index.html").write_text(page, encoding="utf-8")
(OUT / "publications.bib").write_text("\n\n".join(bibtex(p) for p in accepted_papers + pubs) + "\n", encoding="utf-8")
(OUT / ".nojekyll").touch()
print(f"Built {len(accepted_papers)} accepted and {len(pubs)} published papers: {OUT / 'index.html'}")
