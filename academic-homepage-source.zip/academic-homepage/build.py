"""Build the static homepage using Python's standard library: python build.py."""
import html
import json
from datetime import date
from pathlib import Path
from urllib.parse import quote

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "site"
DATA = json.loads((ROOT / "content.json").read_text(encoding="utf-8"))
E = html.escape
POLICY = "https://journals.ieeeauthorcenter.ieee.org/become-an-ieee-journal-author/publishing-ethics/guidelines-and-policies/post-publication-policies/"


def bi(en, zh):
    return f'<span lang="en" class="en">{E(en)}</span><span lang="zh-CN" class="zh">{E(zh)}</span>'


def bibtex(p):
    kind = "article" if p["type"] == "journal" else "inproceedings"
    venue = "journal" if p["type"] == "journal" else "booktitle"
    authors = " and ".join(f'{a.split()[-1]}, {" ".join(a.split()[:-1])}' for a in p.get("authors_full", p["authors"]))
    fields = {"title": "{" + p["title"] + "}", "author": authors, venue: p["venue"], "year": str(p["year"])}
    for key in ("volume", "number", "pages", "doi"):
        if p.get(key):
            fields[key] = str(p[key]).replace("--", "-").replace("-", "--") if key == "pages" else str(p[key])
    if p.get("status") == "accepted":
        fields["note"] = "Accepted for publication on " + p["accepted_date"]
    return "@" + kind + "{" + p["id"] + ",\n" + ",\n".join(f"  {k} = {{{v}}}" for k, v in fields.items()) + "\n}"


def paper(p, index):
    names = p.get("authors_full", p["authors"])
    authors = ", ".join(f'<strong>{E(a)}</strong>' if a in ("C. Xu", DATA["name"]) else E(a) for a in names)
    scholar = ("https://scholar.google.com/citations?view_op=view_citation&user=MgbQBswAAAAJ&citation_for_view=MgbQBswAAAAJ:" + quote(p["scholar_id"])) if p.get("scholar_id") else None
    url = "https://doi.org/" + p["doi"] if p.get("doi") else scholar
    first = f'<span class="first-author">{bi("First author", "第一作者")}</span>' if names[0] in ("C. Xu", DATA["name"]) else ""
    pdf = ""
    copyright = ""
    if p.get("pdf"):
        path = (OUT / p["pdf"]).resolve()
        if not path.is_relative_to((OUT / "papers").resolve()) or not path.is_file():
            raise ValueError(f"PDF must exist inside site/papers: {p['id']}")
        if not p.get("copyright_year") or not p.get("copyright_notice") or not p.get("doi"):
            raise ValueError("Add the verified copyright year, required notice, and DOI before publishing a manuscript")
        pdf = f'<a class="pdf-link" href="{E(p["pdf"], quote=True)}" target="_blank" rel="noopener">{bi("Accepted manuscript · PDF", "作者接收稿 · PDF")}</a>'
        copyright = f'<p class="copyright-notice">{E(p["copyright_notice"])}</p>'
    kind = bi("Journal article", "期刊论文") if p["type"] == "journal" else bi("Conference paper", "会议论文")
    citation = bibtex(p)
    accepted = p.get("status") == "accepted"
    status = f'<span class="accepted-badge">{bi("Accepted", "已接收")}</span>' if accepted else ""
    acceptance = ""
    if accepted:
        accepted_date = date.fromisoformat(p["accepted_date"])
        acceptance = f'<p class="acceptance-date">{bi("Accepted on", "接收日期")} <time datetime="{accepted_date.isoformat()}">{accepted_date:%Y-%m-%d}</time></p>'
    title = f'<a href="{E(url)}" target="_blank" rel="noopener">{E(p["title"])}</a>' if url else E(p["title"])
    links = []
    if p.get("doi"):
        label = "DOI: " + E(p["doi"]) if accepted else bi("Publisher", "出版商页面")
        links.append(f'<a href="https://doi.org/{E(p["doi"], quote=True)}" target="_blank" rel="noopener">{label}</a>')
    if scholar:
        links.append(f'<a href="{E(scholar)}" target="_blank" rel="noopener">Google Scholar</a>')
    links.append(pdf)
    return f'''<article class="paper" id="{E(p['id'])}" aria-labelledby="title-{E(p['id'])}">
      <div class="paper-index" aria-hidden="true">{index:02d}</div>
      <div class="paper-content">
        <div class="paper-meta"><span class="venue-short">{E(p['venue_short'])}</span><span>{kind}</span>{first}{status}</div>
        <h3 id="title-{E(p['id'])}">{title}</h3>
        <p class="authors">{authors}</p>
        <p class="venue">{E(p['venue'])}{', ' + E(str(p['volume'])) if p.get('volume') else ''}{'(' + E(str(p['number'])) + ')' if p.get('number') else ''}{', pp. ' + E(p['pages']) if p.get('pages') else ''} · {p['year']}</p>
        {acceptance}
        <div class="paper-links">{''.join(links)}</div>
        <details class="citation"><summary aria-label="BibTeX: {E(p['title'], quote=True)}">BibTeX</summary><div class="citation-box"><pre><code>{E(citation)}</code></pre><button class="copy-button" type="button" hidden>{bi("Copy citation", "复制引用")}</button></div></details>
        {copyright}
      </div>
    </article>'''


OUT.mkdir(exist_ok=True)
all_papers = DATA["publications"]
if len({p["id"] for p in all_papers}) != len(all_papers):
    raise ValueError("Publication ids must be unique")
if any(p.get("status", "published") not in {"published", "accepted"} for p in all_papers):
    raise ValueError("Publication status must be published or accepted")
accepted_papers = sorted((p for p in all_papers if p.get("status") == "accepted"), key=lambda p: p["accepted_date"], reverse=True)
pubs = sorted((p for p in all_papers if p.get("status") != "accepted"), key=lambda p: p["year"], reverse=True)
accepted_section = ""
accepted_nav = ""
if accepted_papers:
    accepted_cards = ''.join(paper(p, i) for i, p in enumerate(accepted_papers, 1))
    accepted_section = f'<section id="accepted" class="accepted-publications" aria-labelledby="accepted-heading"><div class="section-heading"><h2 id="accepted-heading">{bi("Accepted", "已接收论文")}<span class="paper-count">{len(accepted_papers):02d}</span></h2></div>{accepted_cards}</section>'
    accepted_nav = f'<a href="#accepted">{bi("Accepted", "已接收")}</a>'
sections, count = [], 0
for year in sorted({p["year"] for p in pubs}, reverse=True):
    papers = [p for p in pubs if p["year"] == year]
    cards = []
    for p in papers:
        count += 1
        cards.append(paper(p, count))
    sections.append(f'<section class="year-group" aria-labelledby="year-{year}"><div class="year-heading"><h3 id="year-{year}">{year}</h3><span>{len(papers)} {bi("publications", "篇论文")}</span><div></div></div>{"".join(cards)}</section>')

structured = {"@context": "https://schema.org", "@type": "Person", "name": DATA["name"], "alternateName": DATA["name_zh"], "url": f'https://{DATA["github"].lower()}.github.io/', "sameAs": [DATA["scholar"], f'https://github.com/{DATA["github"]}'], "affiliation": {"@type": "Organization", "name": "Ningbo Institute of Materials Technology and Engineering, Chinese Academy of Sciences"}, "knowsAbout": ["Skill learning", "Imitation learning", "Pattern recognition", "Human-robot interaction"]}
page = f'''<!doctype html>
<html lang="en" data-language="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="theme-color" content="#173bb5">
  <title>{E(DATA['name'])} · {E(DATA['name_zh'])} | Research &amp; Publications</title>
  <meta name="description" content="Chan Xu (许阐) — research and publications in skill learning, imitation learning, pattern recognition, and human-robot interaction at NIMTE, Chinese Academy of Sciences.">
  <meta property="og:title" content="Chan Xu | Research &amp; Publications">
  <meta property="og:description" content="Research and publications · Ningbo Institute of Materials Technology and Engineering, Chinese Academy of Sciences.">
  <meta property="og:type" content="website">
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='12' fill='%23173bb5'/%3E%3Ctext x='32' y='42' text-anchor='middle' font-family='Arial' font-size='30' font-weight='700' fill='white'%3ECX%3C/text%3E%3C/svg%3E">
  <link rel="stylesheet" href="assets/style.css">
  <script src="assets/site.js" defer></script>
  <script type="application/ld+json">{json.dumps(structured, ensure_ascii=False).replace('<', chr(92) + 'u003c')}</script>
</head>
<body>
<a class="skip-link" href="#publications">{bi('Skip to publications', '跳转到论文列表')}</a>
<header class="topbar"><div class="topbar-inner">
  <a class="brand" href="#top" aria-label="Chan Xu homepage"><span class="brand-mark" aria-hidden="true">CX</span><span>Chan Xu<span class="brand-note">{bi(' / Academic homepage', ' / 学术主页')}</span></span></a>
  <nav aria-label="Main navigation">{accepted_nav}<a href="#publications">{bi('Publications', '论文')}</a><a href="#research">{bi('Research', '研究方向')}</a><button id="language-toggle" type="button" aria-label="切换为中文" hidden>中文</button></nav>
</div></header>
<main id="top" class="layout">
  <aside class="profile" aria-labelledby="profile-name">
    <div class="profile-intro"><div class="eyebrow">RESEARCH PROFILE</div><h1 id="profile-name">Chan Xu<span class="chinese-name">许阐</span></h1>
    <div class="profile-rule"></div>
    <p class="affiliation">{bi('Ningbo Institute of Materials Technology and Engineering', '中国科学院宁波材料技术与工程研究所')}</p>
    <p class="academy">{bi('Chinese Academy of Sciences', 'Chinese Academy of Sciences')}</p>
    <p class="location">{bi('Ningbo, China', '中国 · 宁波')}</p>
    <div class="profile-links"><a class="primary-link" href="{E(DATA['scholar'])}" target="_blank" rel="noopener">Google Scholar</a><a class="secondary-link" href="https://github.com/{E(DATA['github'])}" target="_blank" rel="noopener">GitHub</a></div></div>
    <section id="research" class="research" aria-labelledby="research-title"><h2 id="research-title">{bi('Research interests', '研究方向')}</h2><ul><li>{bi('Skill learning', '技能学习')}</li><li>{bi('Imitation learning', '模仿学习')}</li><li>{bi('Pattern recognition', '模式识别')}</li><li>{bi('Human–robot interaction', '人机交互')}</li></ul></section>
    <a class="all-citations" href="{E(DATA['scholar'])}" target="_blank" rel="noopener">{bi('View citation metrics on Google Scholar', '在谷歌学术查看实时引用数据')}</a>
  </aside>
  <div class="main-column">
    <section class="introduction" aria-labelledby="intro-heading"><p class="eyebrow">LEARNING · PERCEPTION · INTERACTION</p><h2 id="intro-heading">{bi('Research & publications', '研究与论文')}</h2><p>{bi('My research interests include skill learning, imitation learning, pattern recognition, and human–robot interaction.', '我的研究兴趣包括技能学习、模仿学习、模式识别与人机交互。')}</p></section>
    {accepted_section}
    <section id="publications" class="publications" aria-labelledby="pub-heading"><div class="section-heading"><h2 id="pub-heading">{bi('Publications', '发表论文')}<span class="paper-count">{len(pubs):02d}</span></h2><a href="publications.bib" download>{bi('Download BibTeX', '下载 BibTeX')}</a></div>
      {''.join(sections)}
    </section>
    <section class="manuscript-note" aria-labelledby="access-heading"><div class="note-symbol" aria-hidden="true">i</div><div><h2 id="access-heading">{bi('Access to papers', '论文获取')}</h2><p>{bi('Publisher links lead to the version of record. Any author accepted manuscript shared on this website is identified separately and remains subject to the applicable copyright notice.', '出版商链接指向正式发表版本。本站分享的作者接收稿将单独标注，并附相应版权声明。')}</p><a href="{POLICY}" target="_blank" rel="noopener">{bi('IEEE article sharing policy', 'IEEE 论文分享政策')}</a></div></section>
    <footer><span>© {DATA['updated'][:4]} Chan Xu</span><span>{bi('Last updated', '更新日期')} <time datetime="{DATA['updated']}">{DATA['updated']}</time></span><a href="#top">{bi('Back to top', '返回顶部')}</a></footer>
  </div>
</main>
<div id="copy-status" class="sr-only" role="status" aria-live="polite"></div>
</body></html>'''
(OUT / "index.html").write_text(page, encoding="utf-8")
(OUT / "publications.bib").write_text("\n\n".join(bibtex(p) for p in accepted_papers + pubs) + "\n", encoding="utf-8")
(OUT / ".nojekyll").touch()
print(f"Built {len(accepted_papers)} accepted and {len(pubs)} published papers: {OUT / 'index.html'}")
