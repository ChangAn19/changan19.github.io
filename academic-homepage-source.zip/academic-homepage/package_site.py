"""Make a flat, browser-uploadable Pages bundle without external dependencies."""
from pathlib import Path
import shutil
import zipfile

root = Path(__file__).resolve().parent
site = root / 'site'
out = root / 'upload'
out.mkdir(exist_ok=True)
html = (site / 'index.html').read_text(encoding='utf-8')
css = (site / 'assets/style.css').read_text(encoding='utf-8')
js = (site / 'assets/site.js').read_text(encoding='utf-8')
html = html.replace('<link rel="stylesheet" href="assets/style.css">', '<style>\n' + css + '\n</style>')
html = html.replace('<script src="assets/site.js" defer></script>', '')
html = html.replace('</body>', '<script>\n' + js + '\n</script>\n</body>')
(out / 'index.html').write_text(html, encoding='utf-8')
shutil.copyfile(site / 'publications.bib', out / 'publications.bib')
shutil.copyfile(root / 'SOURCES.md', out / 'SOURCES.md')
(out / 'README.md').write_text('''# Chan Xu · 许阐

Personal academic homepage: https://changan19.github.io/

This repository contains the published static homepage. GitHub Pages serves the
`main` branch from `/(root)`. The page includes its own CSS and JavaScript, so no
build system, external fonts, or paid service is required.

## 更新主页

- `index.html`：已发布主页，可以直接编辑文字。
- `publications.bib`：论文引用文件。
- `academic-homepage-source.zip`：完整可编辑源码，含 `content.json`、生成器、样式与自动发布工作流。
- `SOURCES.md`：公开资料的核验来源。

建议下载并解压源码包，编辑 `content.json` 后运行 `python build.py` 和
`python package_site.py`，再将生成的 `upload/` 内文件上传替换当前仓库文件。
提交到 `main` 后 GitHub Pages 会更新网站。

如改用源码包中的 GitHub Actions 发布方式，请先按源码 README 保留目录结构，
再在 Settings → Pages 中将 Source 改为 GitHub Actions。

## 作者接收稿

目前仅展示公开论文信息与 DOI，没有上传论文 PDF。日后添加接收稿前，请按每篇
论文的出版协议确认版本与分享权利，在 PDF 首页及网页条目加入相应版权声明、
完整引文与 DOI。不要将非开放获取论文的出版商排版版或校样当作接收稿上传。

IEEE policy: https://journals.ieeeauthorcenter.ieee.org/become-an-ieee-journal-author/publishing-ethics/guidelines-and-policies/post-publication-policies/
''', encoding='utf-8')
archive = out / 'academic-homepage-source.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for file in root.rglob('*'):
        relative = file.relative_to(root)
        if file.is_file() and not any(part in {'upload', '__pycache__', 'qa', '.git'} for part in relative.parts):
            z.write(file, Path(root.name) / relative)
shutil.copyfile(archive, root.parent / 'ChangAn19-academic-homepage.zip')
print('Ready to upload:', ', '.join(p.name for p in out.iterdir() if p.is_file()))
