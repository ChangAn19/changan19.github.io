"""Make a flat, browser-uploadable Pages bundle without external dependencies."""
from pathlib import Path
import base64
import html as html_module
import json
import shutil
import zipfile

root = Path(__file__).resolve().parent
site = root / 'site'
out = root / 'upload'
out.mkdir(exist_ok=True)
html = (site / 'index.html').read_text(encoding='utf-8')
css = (site / 'assets/style.css').read_text(encoding='utf-8')
js = (site / 'assets/site.js').read_text(encoding='utf-8')
html = html.replace('<link rel="stylesheet" href="assets/style.css">', '<style>\n' + css + '\n</style>')
html = html.replace('<script src="assets/site.js" defer></script>', '')
html = html.replace('</body>', '<script>\n' + js + '\n</script>\n</body>')
data = json.loads((root / 'content.json').read_text(encoding='utf-8'))
copied = set()
for paper in data['publications']:
    if paper.get('thumbnail'):
        thumbnail = (site / paper['thumbnail']).resolve()
        if not thumbnail.is_relative_to((site / 'assets').resolve()) or not thumbnail.is_file() or thumbnail.suffix.lower() != '.png':
            raise ValueError('Thumbnail must be a PNG inside site/assets')
        image_uri = 'data:image/png;base64,' + base64.b64encode(thumbnail.read_bytes()).decode('ascii')
        html = html.replace('src="' + html_module.escape(paper['thumbnail'], quote=True) + '"', 'src="' + image_uri + '"')
    if not paper.get('pdf'):
        continue
    source = (site / paper['pdf']).resolve()
    if not source.is_relative_to((site / 'papers').resolve()) or not source.is_file():
        raise ValueError('Manuscript PDF must exist inside site/papers')
    if source.name in copied:
        raise ValueError('Manuscript PDF filenames must be unique for flat uploads')
    copied.add(source.name)
    shutil.copyfile(source, out / source.name)
    html = html.replace('href="' + html_module.escape(paper['pdf'], quote=True) + '"', 'href="' + html_module.escape(source.name, quote=True) + '"')
(out / 'index.html').write_text(html, encoding='utf-8')
shutil.copyfile(site / 'publications.bib', out / 'publications.bib')
shutil.copyfile(root / 'SOURCES.md', out / 'SOURCES.md')
(out / 'README.md').write_text('''# Chan Xu · 许阐

Personal academic homepage: https://changan19.github.io/

This repository contains the published static homepage. GitHub Pages serves the
`main` branch from `/(root)`. The page includes its own CSS and JavaScript, so no
build system, external fonts, or paid service is required.

The homepage focuses on Research Works, with publication thumbnails, year groups,
topic and first-author filters, English/Chinese switching, and PDF downloads.

## 更新主页

- `index.html`：已发布主页，可以直接编辑文字。
- `publications.bib`：论文引用文件。
- `academic-homepage-source.zip`：完整可编辑源码，含 `content.json`、生成器、样式与自动发布工作流。
- `SOURCES.md`：公开资料的核验来源。

建议下载并解压源码包，编辑 `content.json` 后运行 `python build.py` 和
`python package_site.py`，再将生成的 `upload/` 内文件上传替换当前仓库文件。
提交到 `main` 后 GitHub Pages 会更新网站。

如改用源码包中的 GitHub Actions 发布方式，请先按源码 README 保留目录结构，
再在 Settings → Pages 中将 Source 改为 GitHub Actions。

## 作者接收稿

主页单独列出 Accepted / 已接收论文，并显示接收日期、DOI 和作者接收稿下载。
PDF 与 index.html 一起上传到仓库根目录，链接与文件名必须对应。
添加接收稿前，请按每篇论文的出版协议确认版本与分享权利，在 PDF 首页及网页
条目加入相应版权声明、完整引文与 DOI。不要将非开放获取论文的出版商排版版
或校样当作接收稿上传。

IEEE policy: https://journals.ieeeauthorcenter.ieee.org/become-an-ieee-journal-author/publishing-ethics/guidelines-and-policies/post-publication-policies/
''', encoding='utf-8')
archive = out / 'academic-homepage-source.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for file in root.rglob('*'):
        relative = file.relative_to(root)
        if file.is_file() and not any(part in {'upload', '__pycache__', 'qa', '.git'} for part in relative.parts):
            z.write(file, Path(root.name) / relative)
shutil.copyfile(archive, root.parent / 'ChangAn19-academic-homepage.zip')
print('Ready to upload:', ', '.join(p.name for p in out.iterdir() if p.is_file()))
